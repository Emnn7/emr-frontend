import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../api/axios';

export const fetchAllMedicalReports = createAsyncThunk(
  'medicalReports/fetchAll',
  async (_, { rejectWithValue }) => {
    try {
      const response = await api.get('medical-reports/', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('authToken')}`,
          'Content-Type': 'application/json'
        }
      });

      // Axios already parses JSON, so just return the data
      return response.data.data.reports; // Adjusted to match your backend response structure
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || error.message);
    }
  }
);

const medicalReportSlice = createSlice({
  name: 'medicalReports',
  initialState: {
    reports: [], // This should only contain metadata, not Blobs
    loading: false,
    error: null
  },
  reducers: {
    clearReports: (state) => {
      state.reports = [];
      state.error = null;
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchAllMedicalReports.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchAllMedicalReports.fulfilled, (state, action) => {
        state.loading = false;
        state.reports = action.payload;
      })
      .addCase(fetchAllMedicalReports.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  }
});

export const { clearReports } = medicalReportSlice.actions;
export default medicalReportSlice.reducer;