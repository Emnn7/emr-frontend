import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchLabTestCatalog, addLabTestToCatalog } from '../../redux/slices/labTestCatalogSlice';
import {
  Box, Typography, Paper, TextField, Button, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, Switch, FormControlLabel
} from '@mui/material';

const LabTestCatalog = () => {
  const dispatch = useDispatch();
  const { tests, loading } = useSelector((state) => state.labTestCatalog);

 const [newTest, setNewTest] = useState({
  name: '',
  code: '',
  category: '',
  description: '',
  isActive: true,
});


  useEffect(() => {
    dispatch(fetchLabTestCatalog());
  }, [dispatch]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewTest((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleToggle = () => {
    setNewTest((prev) => ({
      ...prev,
      isActive: !prev.isActive,
    }));
  };

  const handleAddTest = () => {
    const { name, code, category } = newTest;
    if (name.trim() && code.trim() && category.trim()) {
      dispatch(addLabTestToCatalog({
        ...newTest,
        name: name.trim(),
        code: code.trim(),
        category: category.trim(),
        description: newTest.description.trim(),
      }));
      setNewTest({
        name: '',
        code: '',
        category: '',
        description: '',
        isActive: true,
      });
    }
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Lab Test Catalog
      </Typography>

      <Paper sx={{ p: 2, mb: 3 }}>
        <Typography variant="h6">Add New Test</Typography>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
          <TextField
            label="Test Name"
            name="name"
            value={newTest.name}
            onChange={handleChange}
            fullWidth
          />
          <TextField
            label="Test Code"
            name="code"
            value={newTest.code}
            onChange={handleChange}
            fullWidth
          />
          <TextField
            label="Category"
            name="category"
            value={newTest.category}
            onChange={handleChange}
            fullWidth
          />
          <TextField
            label="Description (optional)"
            name="description"
            value={newTest.description}
            onChange={handleChange}
            fullWidth
            multiline
            rows={2}
          />
          <FormControlLabel
            control={
              <Switch
                checked={newTest.isActive}
                onChange={handleToggle}
              />
            }
            label="Active"
          />
          <Button variant="contained" onClick={handleAddTest}>
            Add Test
          </Button>
        </Box>
      </Paper>

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Test Name</TableCell>
              <TableCell>Code</TableCell>
              <TableCell>Category</TableCell>
              <TableCell>Active</TableCell>
              <TableCell>Created At</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {loading ? (
              <TableRow><TableCell colSpan={5}>Loading...</TableCell></TableRow>
            ) : (
              tests.map((test) => (
                <TableRow key={test._id}>
                  <TableCell>{test.name}</TableCell>
                  <TableCell>{test.code}</TableCell>
                  <TableCell>{test.category}</TableCell>
                  <TableCell>{test.isActive ? 'Yes' : 'No'}</TableCell>
                  <TableCell>{new Date(test.createdAt).toLocaleDateString()}</TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export default LabTestCatalog;
